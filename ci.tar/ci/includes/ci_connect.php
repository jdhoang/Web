<?php
include_once 'ci_config.php';
$conn = new mysqli(HOST, USER, PASSWORD, DATABASE);
?>
