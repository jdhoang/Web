<?php
define("HOST", "localhost");
define("USER", "ci_user");
define("PASSWORD", "123password");
define("DATABASE", "critical_incidents");
?>
