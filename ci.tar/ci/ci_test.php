<?php
ini_set('display_errors', 'On');
error_reporting(E_ALL | E_STRICT);
?>
<!DOCTYPE html>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<html>
<head>
<title>Critical Incidents Database</title>
<style style="text/css">
<!--
   table          {border-collapse: collapse; border-spacing: 0;}
   *              {font-family: Arial; font-size: 12pt}
   h3             {font-family: Arial; font-size: 16pt}
   p              {font-family: Arial; font-size: 12pt}
   option         {font-family: Arial; font-size: 12pt; color: blue}
   td             {font-family: Arial; font-size: 12pt; vertical-align: top}
   th             {font-family: Arial; font-size: 12pt; font-weight:bold;
                   background: #336699; color: white; vertical-align: top;
                   text-align: left}
   input          {font-family:Arial; color: blue}
   ..box          {border-top:1px #999999 solid;border-left:1px #999999 solid;
                   border-right:1px #000000 solid;border-bottom:1px #000000
                   solid;font-family:Arial;text-transform:uppercase;color: blue}
   a              {color: blue; text-decoration: none; font-size: 12pt}
   a:hover        {color: magenta; text-decoration: none}
   ..error        {color: #FF0000; font-family: Arial; font-size: 10pt;
                   font-weight: bold;}
   ..msg          {color: #CC0000; font-family: Arial; font-size: 9pt;
                   font-weight: bold;}
   ..lefttext     {color: #000000; font-family: Arial,Verdana; font-size: 11px;}
   ..footer       {color: #FFFFFF; font-family: Arial,Verdana; font-size: 11px;}
   ..date         {color: #FFFFFF; font-family: Arial, Verdana; font-size: 12pt;}
   a.link         {color:#003399; font-family: Arial; font-size: 12pt;
                   text-decoration: none;}
   a.link:visited {color:#003399; font-family: Arial; font-size: 12pt;
                   text-decoration: none;}
   a.link:hover   {color:#FFFF00; font-family: Arial; font-size: 12pt;
                   text-decoration: underline;}
   a.link:active  {color:#FFFF00; font-family: Arial; font-size: 12pt;
                   text-decoration: underline;}
   ..pwinput      {border-top:1px #999999 solid;border-left:1px #999999
                   solid; border-right:1px #000000 solid;
                   border-bottom:1px #000000 solid; height: 19px;width: 180px;
                   font-family: Arial;}
   .style15       {font-size: 14px}

   .titleTab          {border-radius: 10px; width:100%; border-collapse:collapse;}
   .titleTab th       {font-family: Copperplate,"Copperplate Gothic Light",fantasy; font-size: 24pt; font-weight:bold;
                       background: black; color: white; vertical-align: middle;
                       text-align: left; padding: 7px; border:black 1px solid}
   .titleTab td       {font-family: Arial; font-size: 12pt; font-weight:bold;
                       background: black; color: white; vertical-align: middle;
                       text-align: left; padding: 7px; border:black 1px solid}

   .menuTab           {width:100%; border-collapse:collapse}
   .menuTab  th       {font-family: Arial; font-size: 12pt; font-weight:bold;
                       background: #336699; color: white; vertical-align: top;
                       text-align: left; padding: 7px; border:#4e95f4 1px solid}
   .menuTab  td       {padding: 7px; border:#4e95f4 1px solid; color: white}
   .menuTab  tr:hover {background-color: lightyellow}

   .hoverTab          {width:100%; border-collapse:collapse}
   .hoverTab th       {font-family: Arial; font-size: 12pt; font-weight:bold;
                       background: #336699; color: white; vertical-align: top;
                       text-align: left; padding: 7px; border:#4e95f4 1px solid}
   .hoverTab td       {padding: 7px; border:#4e95f4 1px solid}
   .hoverTab tr:hover {background-color: lightyellow}
//-->
</style>
<link rel="stylesheet" href="css/ci_dash.css" type="text/css">
<script>
<!--
function disp(str) {
   if (str.length == 0) {
      document.getElementById("mTab").innerHTML = "";
      return;
      }
   else {
      if (window.XMLHttpRequest) 
         xmlhttp = new XMLHttpRequest();
      else
         xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");

      xmlhttp.onreadystatechange = function () {
         if (this.readyState == 4 && this.status == 200) {
            document.getElementById("mTab").innerHTML = this.responseText;
            }
         }
      xmlhttp.open ("GET", str, true);
      xmlhttp.send ();
      }
}
function tdisp(str) {
   if (str.length == 0) {
      document.getElementById("dTab").innerHTML = "";
      return;
      }
   else {
      if (window.XMLHttpRequest) 
         xmlhttp1 = new XMLHttpRequest();
      else
         xmlhttp1 = new ActiveXObject("Microsoft.XMLHTTP");

      xmlhttp1.onreadystatechange = function () {
         if (this.readyState == 4 && this.status == 200) {
            document.getElementById("dTab").innerHTML = this.responseText;
            }
         }
      xmlhttp1.open ("GET", "func_tbval.php?sql=select seq AS Seq,val AS Value from "+str+" order by seq", true);
      xmlhttp1.send ();
      }
}
function DisActy() {
   document.getElementById("Area1").innerHTML = "";
   vfrom = document.getElementById("date_from").value;
   vto = document.getElementById("date_to").value;
   if (window.XMLHttpRequest) 
      xmlhttp = new XMLHttpRequest();
   else
      xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");

   xmlhttp.onreadystatechange = function () {
      if (this.readyState == 4 && this.status == 200) {
         document.getElementById("Area1").innerHTML = this.responseText;
         }
      }
   xmlhttp.open ("GET", "dis_acty.php?date_from="+vfrom+"&date_to="+vto, true);
   xmlhttp.send ();
}
//-->
</script>
</head>

<body>
<table class="titleTab">
<tr>
<th>&nbsp;Critical Incidents Database</th>
<td width=15%><img src="/img/sony.jpg"></td>
</tr>
</table><p>

<table width=100% cellspacing=0 cellpadding=5 >
<tr>
<td width=12%>

<table class="menuTab">
<tr bgcolor=lightblue><td><a href="javascript:void();" onclick="disp('ci_dash.php')">
Main&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></td></tr>
<tr bgcolor=lightblue><td><a href="javascript:void();" onclick="disp('dis_activity.php')">
Activities&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></td></tr>
<tr bgcolor=lightblue><td><a href="javascript:void();" onclick="disp('dis_critical_terms.php')">
Critical Terms&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></td></tr>
<tr bgcolor=lightblue><td><a href="javascript:void();" onclick="disp('func_tbval.php?sql=SELECT s.hostname, st.val AS Status, s.purpose, s.description, o.OpCo FROM systems s LEFT OUTER JOIN system_status_type st ON s.system_status_id = st.id LEFT OUTER JOIN OpCo o ON s.OpCo_id = o.id ORDER BY s.hostname&title=Systems')">
Systems&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></td></tr>
<tr bgcolor=lightblue><td><a href="javascript:void();" onclick="disp('func_tbval.php?sql=SELECT u.last_nm AS LastNm,u.first_nm AS FirstNm, u.sony_global_id AS SonyGlobalID, u.display_nm AS Office, u.description FROM users u ORDER BY u.last_nm&title=Users')">
Users&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></td></tr>
<tr bgcolor=lightblue><td><a href="javascript:void();" onclick="disp('func_tbval.php?sql=SELECT f.filename, f.path, f.purpose, mt.family AS Malware FROM files f LEFT OUTER JOIN malware mt ON f.malware_id=mt.id ORDER BY f.id&title=Files')">
Files&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></td></tr>
<tr bgcolor=lightblue><td><a href="javascript:void();" onclick="disp('ci_type.php')">
Type Values&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></td></tr>
<tr bgcolor=lightblue><td><a href="javascript:void();" onclick="disp('func_tbval.php?sql=select id,parent_org,escalation_org,OpCo from OpCo&title=OpCo')">
OpCo&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></td></tr>
<tr bgcolor=lightblue><td><a href="javascript:void();" onclick="disp('func_tbval.php?sql=select family,functionality,description from malware order by id&title=Malware')">
Malware&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></td></tr>
<tr bgcolor=darkblue><th>Query</th></tr>
<tr bgcolor=lightblue><td><a href="qry_activity.php" target=_blank>Query Activities</a></td></tr>
<tr bgcolor=lightblue><td><a href="qry_system.php" target=_blank>Query Systems</a></td></tr>
<tr bgcolor=lightblue><td><a href="ci_sql.php" target=_blank>Query Ad Hoc</a></td>
<tr bgcolor=darkblue><th>Create</th></tr>
<tr bgcolor=lightblue><td><a href="ifrm_systems.php" target=_blank>Add System</a></td></tr>
<tr bgcolor=lightblue><td><a href="ifrm_crit_terms.php" target=_blank>Add Critical Term</a></td></tr>
</table>
</td>

<td>

<div id="mTab">
<?php
include ('ci_dash.php');
?>
</div>

</td>
</table>

</body>
</html>

